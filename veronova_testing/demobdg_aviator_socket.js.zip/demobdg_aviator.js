module.exports = function (winplay_socket) {

    const express = require('express');
    const router = express.Router();
    const axios = require('axios');

    /*
    |--------------------------------------------------------------------------
    | SOCKET CONNECTION
    |--------------------------------------------------------------------------
    */

    winplay_socket.on("connection", (socket) => {

        console.log("✅ Admin Connected");

        /*
        |--------------------------------------------------------------------------
        | FORCE DROP EVENT
        |--------------------------------------------------------------------------
        */

        socket.on("aviator_drop_now", () => {

            console.log("🔥 FORCE CRASH RECEIVED");

            forceCrash = true;

        });

    });

    /*
    |--------------------------------------------------------------------------
    | VARIABLES
    |--------------------------------------------------------------------------
    */

    let thar_betTime = 10;
    let thar_Multipler = 1000;
    let thar_fie = 2;

    let thar_status = 0;
    let thar_periods = 0;

    let previous_status = 0;
    let period_updated = false;

    let thar_userCount = 0;
    let thar_highestamount = 0;

    let thar_adminmultiply = 0;
    let thar_adminpercent = 0;

    let thar_totalamount = 0;
    let thar_min_amount = 0;

    let thar_loss_per = 0;
    let thar_current_total_win = 0;

    let thar_AdminResult = 0;

    /*
    |--------------------------------------------------------------------------
    | FORCE CRASH VARIABLE
    |--------------------------------------------------------------------------
    */

    let forceCrash = false;

    // const thar_ApiUrl = 'https://bdgcassino.siberiancrane.tech/Aviator/';
     const thar_ApiUrl = 'https://root.veronova.co.in/Aviator/';

    let fetchDataInterval;

    /*
    |--------------------------------------------------------------------------
    | FETCH DATA
    |--------------------------------------------------------------------------
    */

    const thar_fetchData = async () => {

        try {

            let thar_betData;

            if ([10, 40, 0].includes(thar_betTime)) {

                const thar_res_BetHistory =
                    await axios.get(`${thar_ApiUrl}result_half_new.php`);

                console.log(
                    "thar_res_BetHistory ",
                    thar_res_BetHistory?.data
                );

                thar_betData = thar_res_BetHistory.data;

                thar_userCount = thar_betData.totalusers;
                thar_highestamount = thar_betData.highestamount;
                thar_adminmultiply = thar_betData.adminmultiply;
                thar_adminpercent = thar_betData.adminpercent;
                thar_totalamount = thar_betData.totalamount;
                thar_min_amount = thar_betData.min_amount;
                thar_periods = thar_betData.game_sr;
                thar_loss_per = thar_betData.loss_per;
                thar_current_total_win = thar_betData.total_win;
            }

            await thar_SlotTime();

            const thar_data = {

                betTime: thar_betTime,

                status: thar_status,

                period: thar_periods,

                timer: parseFloat(thar_Multipler).toFixed(2)

            };

            winplay_socket.emit(
                "demobdg_aviator",
                JSON.stringify(thar_data, null, 2)
            );

        } catch (error) {

            console.error(
                "Error fetching data:",
                error.message
            );

        }

    };

    /*
    |--------------------------------------------------------------------------
    | SLOT TIME
    |--------------------------------------------------------------------------
    */

    const thar_SlotTime = async () => {

        /*
        |--------------------------------------------------------------------------
        | STATUS 0
        |--------------------------------------------------------------------------
        */

        if (
            parseInt(thar_status) === 0 &&
            parseInt(thar_betTime) === 10
        ) {

            const thar_res_BetHistory =
                await axios.get(`${thar_ApiUrl}result_half_new.php`);

            thar_status = 0;

            thar_periods =
                thar_res_BetHistory?.data?.game_sr
                    ? thar_res_BetHistory?.data?.game_sr
                    : 1;

            updateInterval();

        }

        /*
        |--------------------------------------------------------------------------
        | START ROUND
        |--------------------------------------------------------------------------
        */

        if (parseInt(thar_betTime) === 1) {

            if (parseInt(thar_status) === 0) {

                thar_status = 1;

                updateInterval();

            }

            /*
            |--------------------------------------------------------------------------
            | MULTIPLIER TIME
            |--------------------------------------------------------------------------
            */

            await thar_AviatorMultiplerTime();

            /*
            |--------------------------------------------------------------------------
            | FINAL RESULT
            |--------------------------------------------------------------------------
            */

            await thar_FinalAviatorTime();

            /*
            |--------------------------------------------------------------------------
            | FORCE CRASH / NORMAL CRASH
            |--------------------------------------------------------------------------
            */

            if (
                forceCrash ||
                thar_AdminResult <= thar_Multipler
            ) {

                thar_fie -= 1;

                thar_status = 2;

                thar_betTime = 2;

                updateInterval();

                /*
                |--------------------------------------------------------------------------
                | RESULT INSERT
                |--------------------------------------------------------------------------
                */

                if (thar_fie == 2) {

                    await gbaviator_resultinsert();

                }

                console.log(
                    "⏳ Status 2: Waiting for 3 seconds..."
                );

                /*
                |--------------------------------------------------------------------------
                | RESET AFTER CRASH
                |--------------------------------------------------------------------------
                */

                setTimeout(() => {

                    thar_status = 0;

                    thar_Multipler = 1000;

                    thar_betTime = 11;

                    thar_fie = 3;

                    thar_AdminResult = 0;

                    previous_status = 0;

                    period_updated = false;

                    /*
                    |--------------------------------------------------------------------------
                    | RESET FORCE CRASH
                    |--------------------------------------------------------------------------
                    */

                    forceCrash = false;

                    console.log(
                        "🔄 3 seconds over, resetting to status 0"
                    );

                    updateInterval();

                }, 3 * 1000);

            }

        } else {

            /*
            |--------------------------------------------------------------------------
            | BET TIMER
            |--------------------------------------------------------------------------
            */

            thar_betTime = thar_BetTime(thar_betTime);

            /*
            |--------------------------------------------------------------------------
            | START MULTIPLIER
            |--------------------------------------------------------------------------
            */

            if (
                thar_betTime == 1 &&
                thar_status !== 2
            ) {

                thar_Multipler = 0.99;

            }

        }

        /*
        |--------------------------------------------------------------------------
        | SKIP EMIT
        |--------------------------------------------------------------------------
        */

        if (
            thar_betTime === 0 &&
            thar_status === 0
        ) {

            return;

        }

        previous_status = thar_status;

        return thar_Multipler;

    };

    /*
    |--------------------------------------------------------------------------
    | MULTIPLIER INCREASE
    |--------------------------------------------------------------------------
    */

    const thar_AviatorMultiplerTime = async () => {

        if (parseInt(thar_status) === 1) {

            thar_Multipler += (

                thar_Multipler > 50 ? 0.08 :

                (
                    thar_Multipler > 30 ? 0.06 :

                    (
                        thar_Multipler > 20 ? 0.05 :

                        (
                            thar_Multipler > 10 ? 0.04 :

                            (
                                thar_Multipler > 5 ? 0.03 :

                                (
                                    thar_Multipler > 2 ? 0.02 : 0.01
                                )

                            )

                        )

                    )

                )

            );

        }

        return thar_Multipler;

    };

    /*
    |--------------------------------------------------------------------------
    | FINAL RESULT
    |--------------------------------------------------------------------------
    */

    const thar_FinalAviatorTime = async () => {

        if (thar_adminmultiply > 0) {

            thar_AdminResult = thar_adminmultiply;

        } else {

            thar_AdminResult = Math.random() * 100;

        }

        return thar_AdminResult;

    };

    /*
    |--------------------------------------------------------------------------
    | TIMER DECREASE
    |--------------------------------------------------------------------------
    */

    function thar_BetTime(thar_betTime) {

        return thar_betTime - 1;

    }

    /*
    |--------------------------------------------------------------------------
    | UPDATE INTERVAL
    |--------------------------------------------------------------------------
    */

    function updateInterval() {

        clearInterval(fetchDataInterval);

        const interval_timer = (

            thar_status === 1

                ? 100

                : (

                    thar_status === 2

                        ? 2000

                        : 1000

                )

        );

        fetchDataInterval =
            setInterval(
                thar_fetchData,
                interval_timer
            );

    }

    /*
    |--------------------------------------------------------------------------
    | RESULT INSERT
    |--------------------------------------------------------------------------
    */

    function gbaviator_resultinsert() {

        const gbaviator_data = JSON.stringify({

            adminmultiply: thar_Multipler,

            game_sr: thar_periods

        });

        const gbaviator_config = {

            method: 'post',

            maxBodyLength: Infinity,

            url: `${thar_ApiUrl}result_insert_new.php`,

            headers: {

                'Content-Type': 'application/json'

            },

            data: gbaviator_data

        };

        return axios.request(gbaviator_config)

            .then(response => {

                console.log(
                    "JSON.stringify(response.data betxbetx",
                    JSON.stringify(response.data)
                );

            })

            .catch(error => {

                console.error(error);

            });

    }

    /*
    |--------------------------------------------------------------------------
    | START SOCKET
    |--------------------------------------------------------------------------
    */

    updateInterval();

    /*
    |--------------------------------------------------------------------------
    | DISCONNECT
    |--------------------------------------------------------------------------
    */

    winplay_socket.on("disconnect", () => {

        clearInterval(fetchDataInterval);

    });

    return router;

};
{{-- resources/views/admin/aviator/index.blade.php --}}

@extends('admin.body.adminmaster')

@section('admin')

<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins', sans-serif;
}

body{
    background:#0a0a0a;
}

.aviator-main{
    width:100%;
    padding:15px;
}

/* ================= HISTORY ================= */

.top-history{
    width:100%;
    background:#111;
    border-radius:20px;
    border:1px solid #262626;
    padding:8px;
    display:flex;
    align-items:center;
    gap:10px;
    overflow:auto;
    margin-bottom:12px;
}

.top-history::-webkit-scrollbar{ display:none; }

.history-item{
    min-width:70px;
    background:#171717;
    border-radius:40px;
    padding:8px 10px;
    text-align:center;
    font-weight:700;
    font-size:18px;
    border:1px solid #2d2d2d;
}

.red   { color:#ff4949; }
.blue  { color:#4595ff; }
.green { color:#00e676; }
.orange{ color:#ffb347; }
.purple{ color:#bc7cff; }

/* ================= GAME BOX ================= */

.game-box{
    width:100%;
    height:440px;
    position:relative;
    overflow:hidden;
    border-radius:24px;
    border:1px solid #292929;
    background:#000;
}

/* ================= ROTATING BG ================= */

.rotating-bg{
    position:absolute;
    width:340%;
    height:760%;
    left:0%;
    top:110%;
    transform:translate(-50%, -50%);
    background-image:url('https://websocket.pasawin.com/activity_image/chakra.jpeg');
    background-position:center;
    background-size:cover;
    background-repeat:no-repeat;
    opacity:.18;
    z-index:1;
    animation:none;
}

.rotating-bg.active{
    animation:spinBg 15s linear infinite;
}

@keyframes spinBg{
    from{ transform:translate(-50%, -50%) rotate(0deg); }
    to{   transform:translate(-50%, -50%) rotate(360deg); }
}

/* ================= OVERLAY ================= */

.dark-overlay{
    position:absolute;
    inset:0;
    background:rgba(0,0,0,.38);
    z-index:2;
}

/* ================= ROUND ID ================= */

.round-id{
    position:absolute;
    top:18px;
    left:22px;
    color:#8c8c8c;
    font-size:18px;
    z-index:60;
    font-weight:600;
}

/* ================= LEFT DOTS ================= */

.side-dots{
    position:absolute;
    left:12px;
    top:20px;
    bottom:32px;
    width:10px;
    z-index:50;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
}

.side-dots::before{
    content:'';
    position:absolute;
    left:2px; top:0;
    width:2px; height:100%;
    background:rgba(255,0,72,.35);
    box-shadow:0 0 10px rgba(255,0,72,.5);
    z-index:1;
}

.dot{
    width:5px; height:5px;
    border-radius:50%;
    background:#00ff9d;
    box-shadow:0 0 5px #00ff9d, 0 0 10px #00ff9d, 0 0 18px #00ff9d;
    opacity:.35;
    position:relative;
    z-index:2;
}

.dot.active{ animation:dotMove .8s linear infinite; }

@keyframes dotMove{
    0%  { transform:translateY(-8px); opacity:1; }
    100%{ transform:translateY(8px);  opacity:.2; }
}

/* ================= BOTTOM DOTS ================= */

.bottom-dots{
    position:absolute;
    left:30px; right:20px;
    bottom:14px;
    height:10px;
    z-index:50;
    display:flex;
    align-items:center;
    justify-content:space-between;
}

.bottom-dot{
    width:5px; height:5px;
    border-radius:50%;
    background:#00ff9d;
    box-shadow:0 0 5px #00ff9d, 0 0 10px #00ff9d, 0 0 18px #00ff9d;
    opacity:.35;
    position:relative;
    z-index:2;
}

.bottom-dot.active{ animation:bottomDotMove .8s linear infinite; }

@keyframes bottomDotMove{
    0%  { transform:translateX(-5px); opacity:1; }
    100%{ transform:translateX(5px);  opacity:.2; }
}

/* ================= CANVAS ================= */

#aviatorCanvas{
    width:100%; height:100%;
    position:absolute;
    left:0; top:0;
    z-index:5;
}

/* ================= CENTER DISPLAY ================= */

.multiplier-center{
    position:absolute;
    left:50%; top:40%;
    transform:translate(-50%, -50%);
    z-index:70;
    text-align:center;
    pointer-events:none;
}

.main-multiplier{
    font-size:72px;
    color:#fff;
    font-weight:900;
    text-shadow:
        0 0 10px #fff,
        0 0 20px #7f8cff,
        0 0 40px #7f8cff;
}

.waiting-text{
    font-size:32px;
    color:#fff;
    font-weight:800;
    text-shadow:0 0 20px #9ca4ff;
    line-height:1.4;
}

.waiting-icon{
    width:120px;
    margin-bottom:20px;
    filter:drop-shadow(0 0 12px #fff);
}

/* ================= AIRPLANE ================= */

.airplane{
    width:130px;
    position:absolute;
    left:0; bottom:0;
    z-index:80;
    pointer-events:none;
    transition:left .08s linear, top .08s linear;
    transform-origin:center center;
    filter:
        drop-shadow(0 0 10px #ff0048)
        drop-shadow(0 0 22px #ff0048);
}

/* ================= STATS ================= */

.bottom-stats{
    width:100%;
    display:flex;
    gap:10px;
    margin-top:14px;
    flex-wrap:wrap;
}

.stat-box{
    flex:1;
    min-width:180px;
    background:#111;
    border:1px solid #292929;
    border-radius:18px;
    padding:14px;
    text-align:center;
}

.stat-title{
    color:#8d8d8d;
    font-size:14px;
    margin-bottom:8px;
    font-weight:600;
}

.stat-value{
    color:#fff;
    font-size:24px;
    font-weight:800;
}

.drop-box{
    background:#ff0048;
    cursor:pointer;
    transition:.2s;
}

.drop-box:hover{ transform:scale(1.03); }

.drop-box .stat-title,
.drop-box .stat-value{ color:#fff; }

/* ================= MOBILE ================= */

@media(max-width:768px){
    .game-box{ height:380px; }
    .main-multiplier{ font-size:50px; }
    .waiting-text{ font-size:22px; }
    .airplane{ width:100px; }
}

</style>

<div class="aviator-main">

    {{-- HISTORY --}}
    <div class="top-history" id="historyBox"></div>

    {{-- GAME --}}
    <div class="game-box">

        <div class="rotating-bg" id="rotatingBg"></div>
        <div class="dark-overlay"></div>

        {{-- LEFT DOTS --}}
        <div class="side-dots" id="sideDots">
            <div class="dot"></div><div class="dot"></div><div class="dot"></div>
            <div class="dot"></div><div class="dot"></div><div class="dot"></div>
            <div class="dot"></div><div class="dot"></div><div class="dot"></div>
            <div class="dot"></div>
        </div>

        {{-- BOTTOM DOTS --}}
        <div class="bottom-dots" id="bottomDots">
            <div class="bottom-dot"></div><div class="bottom-dot"></div>
            <div class="bottom-dot"></div><div class="bottom-dot"></div>
            <div class="bottom-dot"></div><div class="bottom-dot"></div>
            <div class="bottom-dot"></div><div class="bottom-dot"></div>
            <div class="bottom-dot"></div><div class="bottom-dot"></div>
            <div class="bottom-dot"></div><div class="bottom-dot"></div>
            <div class="bottom-dot"></div><div class="bottom-dot"></div>
        </div>

        <div class="round-id">Round ID : <span id="roundId">0</span></div>

        {{-- CENTER --}}
        <div class="multiplier-center">
            <img
                src="https://websocket.pasawin.com/activity_image/fan_aviator.gif"
                class="waiting-icon"
                id="waitingIcon"
            >
            <div class="waiting-text" id="waitingText">WAITING...</div>
            <div class="main-multiplier" id="mainMultiplier" style="display:none;">1.00x</div>
        </div>

        {{-- PLANE --}}
        <img
            src="https://websocket.pasawin.com/activity_image/aviator.gif"
            class="airplane"
            id="plane"
        >

        {{-- CANVAS --}}
        <canvas id="aviatorCanvas"></canvas>

    </div>

    {{-- STATS --}}
    <div class="bottom-stats">
        <div class="stat-box">
            <div class="stat-title">TOTAL BET</div>
            <div class="stat-value" id="totalBet">₹0</div>
        </div>
        <div class="stat-box">
            <div class="stat-title">TOTAL CASHOUT</div>
            <div class="stat-value" id="totalCashout">₹0</div>
        </div>
        <div class="stat-box drop-box" id="dropNowBtn">
            <div class="stat-title">ADMIN</div>
            <div class="stat-value">DROP NOW</div>
        </div>
        <div class="stat-box">
            <div class="stat-title">MULTIPLIER</div>
            <div class="stat-value" id="liveMultiplierAmount">₹0</div>
        </div>
        <div class="stat-box">
            <div class="stat-title">TOTAL PLAYER</div>
            <div class="stat-value" id="totalPlayer">0</div>
        </div>
    </div>

</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.socket.io/4.7.5/socket.io.min.js"></script>

<script>

/* =====================================================
   CONFIG
===================================================== */

const SOCKET_URL = "https://aviatorudaan.com";
const EVENT_NAME = "demobdg_aviator";

/* =====================================================
   CANVAS
===================================================== */

const canvas = document.getElementById('aviatorCanvas');
const ctx    = canvas.getContext('2d');
const plane  = document.getElementById('plane');

function resizeCanvas() {
    canvas.width  = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
}
resizeCanvas();
window.addEventListener('resize', resizeCanvas);

function getBaselineY() {
    return canvas.height - 38;
}

/* =====================================================
   GRAPH STATE
===================================================== */

let graphPoints = [];
let lastPeriod  = null;
let tickCount   = 0;

/* =====================================================
   RESET
===================================================== */

function resetGraph() {
    graphPoints = [];
    tickCount   = 0;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    plane.style.left      = '0px';
    plane.style.bottom    = '30px';
    plane.style.top       = 'auto';
    plane.style.opacity   = '1';
    plane.style.transform = 'rotate(-5deg)';
}

/* =====================================================
   DRAW GREEN BASELINE
===================================================== */

function drawBaseline() {
    let by = getBaselineY();

    ctx.save();
    ctx.beginPath();
    ctx.moveTo(26, by);
    ctx.lineTo(canvas.width - 16, by);

    ctx.strokeStyle  = 'rgba(0, 255, 157, 0.55)';
    ctx.lineWidth    = 1.8;
    ctx.shadowColor  = '#00ff9d';
    ctx.shadowBlur   = 18;
    ctx.setLineDash([6, 8]);
    ctx.lineCap      = 'round';
    ctx.stroke();
    ctx.restore();
}

/* =====================================================
   COMPUTE NEXT POINT
===================================================== */

function computePoint(tick, multiplier) {
    let W  = canvas.width;
    let by = getBaselineY();

    let maxX   = W * 0.75;
    let xRatio = Math.min(tick / 120, 1);
    let x = 10 + maxX * Math.pow(xRatio, 0.65);

    let rise  = Math.pow(multiplier - 1.0, 0.72) * (canvas.height * 0.72);
    let y     = by - rise;

    let minY  = canvas.height * 0.12;
    if (y < minY) y = minY;
    if (y > by - 2) y = by - 2;

    return { x, y };
}

/* =====================================================
   DRAW GRAPH
===================================================== */

function drawGraph() {
    if (graphPoints.length < 2) return;

    let by = getBaselineY();
    let pts = graphPoints;
    let last = pts[pts.length - 1];

    ctx.beginPath();
    ctx.moveTo(pts[0].x, pts[0].y);

    for (let i = 0; i < pts.length - 1; i++) {
        let cx = (pts[i].x + pts[i+1].x) / 2;
        let cy = (pts[i].y + pts[i+1].y) / 2;
        ctx.quadraticCurveTo(pts[i].x, pts[i].y, cx, cy);
    }
    ctx.lineTo(last.x, last.y);

    ctx.strokeStyle = '#ff0048';
    ctx.lineWidth   = 4.5;
    ctx.shadowColor  = '#ff0048';
    ctx.shadowBlur   = 20;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;
    ctx.lineCap  = 'round';
    ctx.lineJoin = 'round';
    ctx.globalCompositeOperation = 'source-over';
    ctx.stroke();

    ctx.lineTo(last.x, by);
    ctx.lineTo(pts[0].x, by);
    ctx.closePath();
    ctx.fillStyle = 'rgba(255, 0, 72, 0.15)';
    ctx.shadowBlur = 0;
    ctx.fill();
}

/* =====================================================
   POSITION PLANE ON TIP OF POLYLINE
===================================================== */

function positionPlane(x, y) {
    let pw = parseInt(plane.style.width) || 130;
    plane.style.left   = (x - 30) + 'px';
    plane.style.top    = (y - 72) + 'px';
    plane.style.bottom = 'auto';

    let angle = -30;
    let pts = graphPoints;
    if (pts.length >= 2) {
        let prev = pts[pts.length - 2];
        let curr = pts[pts.length - 1];
        let dx   = curr.x - prev.x;
        let dy   = curr.y - prev.y;
        angle    = Math.atan2(dy, dx) * (180 / Math.PI);
        angle = Math.max(-55, Math.min(5, angle));
    }
    plane.style.transform = `rotate(${angle}deg) scale(1.05)`;
}

/* =====================================================
   HISTORY FUNCTIONS
===================================================== */

function saveCrashToDatabase(roundId, crashValue) {
    return $.ajax({
        url: '{{ route("aviator.crash.store") }}',
        type: 'POST',
        data: {
            round_id: roundId,
            crash_point: crashValue,
            _token: '{{ csrf_token() }}'
        }
    });
}

function loadHistoryFromDatabase() {
    $.ajax({
        url: '{{ route("aviator.crash.history") }}',
        type: 'GET',
        success: function(history) {
            if (history && history.length) {
                $('#historyBox').empty();
                history.forEach(function(crash) {
                    let colors = ['red','blue','green','orange','purple'];
                    let cls    = colors[Math.floor(Math.random() * colors.length)];
                    $('#historyBox').append(
                        `<div class="history-item ${cls}" data-round="${crash.round_id}" data-crash="${crash.crash_point}">${parseFloat(crash.crash_point).toFixed(2)}x</div>`
                    );
                });
            }
        },
        error: function(xhr) {
            console.error('Failed to load history:', xhr);
        }
    });
}

/* =====================================================
   LIVE DATA FETCH
===================================================== */

function fetchLiveData(period, multiplier) {
    $.ajax({
        url:  '{{ url("admin/get-aviator-live-data") }}',
        type: 'GET',
        data: { period: period },
        success: function(res) {
            $('#totalBet').html('₹' + parseFloat(res.totalBet).toFixed(2));
            $('#totalCashout').html('₹' + parseFloat(res.totalCashout).toFixed(2));
            $('#totalPlayer').html(res.totalPlayer);
            let multi = parseFloat(res.totalBet) * parseFloat(multiplier);
            $('#liveMultiplierAmount').html('₹' + multi.toFixed(2));
        }
    });
}

/* =====================================================
   SOCKET
===================================================== */

const socket = io(SOCKET_URL, {
    transports: ['websocket'],
    secure: true,
    reconnection: true,
    reconnectionAttempts: Infinity,
    reconnectionDelay: 1000
});

socket.on(EVENT_NAME, function(response) {

    let data = typeof response === "string" ? JSON.parse(response) : response;

    $('#roundId').text(data.period);

    /* --- New round detect --- */
    if (lastPeriod !== data.period) {
        lastPeriod = data.period;
        resetGraph();
        $('#totalBet').html('₹0');
        $('#totalCashout').html('₹0');
        $('#liveMultiplierAmount').html('₹0');
        $('#totalPlayer').html('0');
    }

    /* ===== STATUS 0 — Waiting ===== */

    if (parseInt(data.status) === 0) {

        $('#waitingIcon').show();
        $('#waitingText').show().html('WAITING FOR NEXT ROUND <br>' + data.betTime);
        $('#mainMultiplier').hide();

        $('#rotatingBg').removeClass('active');
        $('#sideDots .dot').removeClass('active');
        $('#bottomDots .bottom-dot').removeClass('active');

        resetGraph();
    }

    /* ===== STATUS 1 — Flying ===== */

    if (parseInt(data.status) === 1) {

        $('#waitingIcon').hide();
        $('#waitingText').hide();
        $('#mainMultiplier').show();

        $('#rotatingBg').addClass('active');
        $('#sideDots .dot').addClass('active');
        $('#bottomDots .bottom-dot').addClass('active');

        let multiplier = parseFloat(data.timer);
        $('#mainMultiplier').text(multiplier.toFixed(2) + 'x');

        fetchLiveData(data.period, multiplier);

        tickCount++;

        let pt = computePoint(tickCount, multiplier);
        graphPoints.push(pt);

        ctx.clearRect(0, 0, canvas.width, canvas.height);
        drawBaseline();
        drawGraph();
        positionPlane(pt.x, pt.y);
    }

    /* ===== STATUS 2 — Crashed ===== */

    if (parseInt(data.status) === 2) {

        $('#rotatingBg').removeClass('active');
        $('#sideDots .dot').removeClass('active');
        $('#bottomDots .bottom-dot').removeClass('active');

        let crashValue = parseFloat(data.timer).toFixed(2);
        let roundId = data.period;
        
        // Save to database
        saveCrashToDatabase(roundId, crashValue).then(function(response) {
            if (response.success) {
                // Reload history from database
                loadHistoryFromDatabase();
            }
        });
        
        // Display crash UI
        $('#waitingIcon').hide();
        $('#mainMultiplier').show().html(`
            <div style="font-size:38px;font-weight:800;color:#fff;line-height:1.2;text-shadow:0 0 20px #9ca4ff;">
                Flew away!
            </div>
            <div style="font-size:76px;font-weight:900;color:#fff;text-shadow:0 0 10px #fff,0 0 30px #9ca4ff;">
                ${crashValue}x
            </div>
        `);
        $('#waitingText').hide();

        /* Plane fly away */
        plane.style.transition = 'all .8s ease-in';
        plane.style.left       = (canvas.width + 300) + 'px';
        plane.style.top        = '-200px';
        plane.style.transform  = 'rotate(35deg) scale(.7)';
        plane.style.opacity    = '0';

        setTimeout(() => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        }, 250);

        setTimeout(() => {
            plane.style.transition = '';
            plane.style.opacity    = '1';
            resetGraph();
        }, 1500);
    }

});

/* =====================================================
   DROP NOW BUTTON
===================================================== */

$('#dropNowBtn').click(function() {
    // Emit socket event to crash the game
    socket.emit("aviator_drop_now");
    
    // Show loading state
    $(this).css('opacity', '0.7');
    setTimeout(() => {
        $('#dropNowBtn').css('opacity', '1');
    }, 2000);
});

/* ===================================================== 
   LOAD HISTORY ON PAGE LOAD
===================================================== */

$(document).ready(function() {
    loadHistoryFromDatabase();
});

</script>

@endsection